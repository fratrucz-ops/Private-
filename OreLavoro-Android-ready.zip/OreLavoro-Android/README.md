# Ore Lavoro - Android

App Android semplice per registrare ore lavorative, giorni, settimane e mesi.

Funzioni:
- Entrata/uscita con calcolo automatico ore
- Pausa in minuti
- Inserimento manuale ore
- Straordinari automatici oltre la soglia configurabile
- Ferie e riposi
- Riepilogo settimanale e mensile
- Calendario mensile
- Storico con cancellazione
- Salvataggio locale sul telefono
- Backup JSON

## Creare APK con GitHub Actions
1. Carica l'intero progetto in un repository GitHub.
2. Apri la scheda Actions.
3. Apri "Build APK" e premi "Run workflow" (oppure fai un push su main).
4. A build completata, scarica l'artifact "OreLavoro-APK".
5. Dentro trovi `app-debug.apk`, installabile su Android.
